declare module 'react-terminal-component'
declare module 'javascript-terminal'
