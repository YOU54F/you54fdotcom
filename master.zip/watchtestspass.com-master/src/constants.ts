export enum CUSTOM_TYPE {
    JEST = 'jest',
}